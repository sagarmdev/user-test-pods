/*!
 @brief Visual assets
*/
typedef NS_ENUM(NSInteger, BTUIKVisualAssetType) {
    BTUIKVisualAssetTypeUnknown = 0,
    BTUIKVisualAssetTypeCVVBack,
    BTUIKVisualAssetTypeCVVFront,
};
