//
//  CardinalSessionConfig.h
//  CardinalMobile
//
//  Created by Sudeep Tuladhar on 5/2/19.
//  Copyright © 2019 Cardinal Commerce. All rights reserved.
//

#import <CardinalMobile/CardinalMobile.h>

NS_ASSUME_NONNULL_BEGIN
__attribute__ ((deprecated))
@interface CardinalSessionConfig : CardinalSessionConfiguration

@end

NS_ASSUME_NONNULL_END
