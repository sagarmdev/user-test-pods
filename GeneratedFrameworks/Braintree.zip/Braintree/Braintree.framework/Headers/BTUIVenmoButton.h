#import <UIKit/UIKit.h>

@class BTUI;

/**
 Represents a Venmo button
 */
@interface BTUIVenmoButton : UIControl

@property (nonatomic, strong) BTUI *theme;

@end
