#import <UIKit/UIKit.h>

/// Version number
FOUNDATION_EXPORT double BraintreeDataCollectorVersionNumber;

/// Version string
FOUNDATION_EXPORT const unsigned char BraintreeDataCollectorVersionString[];

#import "BTDataCollector.h"

