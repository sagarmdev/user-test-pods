//
//  PPOTVersion.h
//


#ifndef PPOTVersion_h
#define PPOTVersion_h

#define PayPalOTVersion() @"4.30.2"

#endif
