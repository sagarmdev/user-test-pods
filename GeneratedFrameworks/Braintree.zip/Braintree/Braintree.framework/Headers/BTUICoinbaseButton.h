#import <UIKit/UIKit.h>

@class BTUI;

/**
 Represents a Coinbase button
 */
@interface BTUICoinbaseButton : UIControl

@property (nonatomic, strong) BTUI *theme;

@end
