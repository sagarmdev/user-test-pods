#import <Foundation/Foundation.h>

#pragma mark NSError userInfo Keys

/**
 NSError userInfo key for validation errors.
*/
extern NSString * _Nonnull const BTCustomerInputBraintreeValidationErrorsKey;
