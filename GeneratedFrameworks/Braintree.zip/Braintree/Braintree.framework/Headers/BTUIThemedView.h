#import <UIKit/UIKit.h>
#import "BTUI.h"

/**
 A visual customized UIView
 */
@interface BTUIThemedView : UIView
@property (nonatomic, strong) BTUI *theme;
@end
